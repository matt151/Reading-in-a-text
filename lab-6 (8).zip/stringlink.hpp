#pragma once
#include <string>
#include <iostream>

class stringlink : public std::string/*allows acess to all of foo class*/ {
  /*allows acess to all of foo class*/
//we only want to add oe thing, a pointer to another foolink object.

public:


//must form a constructor 
//foolink(int i);//the constructor
stringlink *next;
 
//use this to link to the next foolink object in the linked list.

}

;
