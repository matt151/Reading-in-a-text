#include <iostream>
#include <string>
#include "stringlink.hpp"

using namespace std;


//taken from lab 5 below:
int main() {//in this main function we are trying to make something that reads in all the words and prints them out again. 


 stringlink*book=nullptr;//book initially has no words, were going yo add them as we go along i.e the book is empty INITIALLY
  cout << "Starting...\n";
  
 
  while (cin.eof() == false) {
   string t_word;
   cin >> t_word;

   stringlink*new_word=new stringlink();//reads in new word

   new_word->assign(t_word);//assigning new word it just read in from the file
   new_word->next=book;//adds the new word to the head of the book linked list
   book=new_word;//book now points to the new word.

   cout<< "the word is \"" << t_word<< "\"."<<endl;
  }


cout <<"stored words are coming out now"<<endl;

stringlink *w=book;
while (w!=nullptr){
cout<< "the word stored is \""<<*w<<"\"."<<endl;
w=w->next;
  
}
cout << "Finished" << endl;

}


